





=上传图片返回   
{
"statusCode": 200,
"errcode": "",
"headers": {},
"body": "/res/uploads/upload_20250417_215120166.jpg",
"message_err": "",
"message": "",
"timestamp": 1744901480170,
"path": "\"/uploads\"",
"requestId": "reqid__964d3d39-b429-4472-9628-231f65a2a434",
"debugInfo": {}
}


=请求图片

http://localhost:8889/res/uploads/upload_20250417_214249182.jpg